package guiSystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.sql.*;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.ImageIcon;

public class OnlineBookstore extends JFrame {

	private JPanel contentPane;
	private JTextField userNametextField;
	private JButton loginBtn;
	private JPasswordField passwWordField;
	private JTextField textField;
	private JLabel userNameLabel;
	private JLabel passwordLabel;
	private JLabel TitleLabel;
	private JLabel NewEraLabel;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OnlineBookstore frame = new OnlineBookstore();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
					
				}
			}
		});
	}


	public OnlineBookstore() {

		String userName = "root";
		String password = "";
		String url = "jdbc:mysql://localhost:3306/guisystem?useSSL=false";

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 483, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel Mainpanel = new JPanel();
		contentPane.add(Mainpanel, BorderLayout.CENTER);
		Mainpanel.setLayout(null);

		NewEraLabel = new JLabel(" New Era University");
		NewEraLabel.setForeground(Color.RED);
		NewEraLabel.setToolTipText("");
		NewEraLabel.setFont(new Font("Palace Script MT", Font.BOLD | Font.ITALIC, 49));
		NewEraLabel.setBounds(77, 13, 341, 43);
		Mainpanel.add(NewEraLabel);

		loginBtn = new JButton("LOG-IN");
		loginBtn.setBackground(SystemColor.controlHighlight);
		loginBtn.setFont(new Font("Candara Light", Font.BOLD, 14));
		loginBtn.setForeground(Color.RED);
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pass = passwWordField.getText();
				String tempUserName = userNametextField.getText();

				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection(url, userName, password);
					String sql = "SELECT * FROM account WHERE userName ='" + userNametextField.getText() + "'";
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(sql);

					while (rs.next()) {
						if (pass.equals(rs.getString("passWord"))
								&& userNametextField.getText().equals(rs.getString("userName"))) {
							CustomerReceipt cr = new CustomerReceipt();
							cr.setVisible(true);
							dispose();

						} else {
							JOptionPane.showMessageDialog(null, "INCORRECT USER/PASSWORD");
						}

					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

			}
		});
		loginBtn.setBounds(193, 211, 97, 23);
		Mainpanel.add(loginBtn);

		passwWordField = new JPasswordField();
		passwWordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pass = passwWordField.getText();
				String tempUserName = userNametextField.getText();

				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection(url, userName, password);
					String sql = "SELECT * FROM account WHERE userName ='" + userNametextField.getText() + "'";
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(sql);

					while (rs.next()) {
						if (pass.equals(rs.getString("passWord"))
								&& userNametextField.getText().equals(rs.getString("userName"))) {
							CustomerReceipt cr = new CustomerReceipt();
							cr.setVisible(true);
							dispose();

						} else {
							JOptionPane.showMessageDialog(null, "INCORRECT USER/PASSWORD");
						}

					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

			}
		});
		passwWordField.setBounds(169, 159, 151, 23);
		Mainpanel.add(passwWordField);

		userNametextField = new JTextField();
		userNametextField.setBounds(169, 125, 151, 21);
		Mainpanel.add(userNametextField);
		userNametextField.setColumns(10);

		userNameLabel = new JLabel("USERNAME :");
		userNameLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		userNameLabel.setBackground(Color.WHITE);
		userNameLabel.setForeground(SystemColor.desktop);
		userNameLabel.setBounds(77, 129, 81, 14);
		Mainpanel.add(userNameLabel);

		passwordLabel = new JLabel("PASSWORD :");
		passwordLabel.setForeground(SystemColor.desktop);
		passwordLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		passwordLabel.setBounds(77, 162, 97, 16);
		Mainpanel.add(passwordLabel);
		
		TitleLabel = new JLabel("---ONLINE BOOK STORE---");
		TitleLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		TitleLabel.setForeground(new Color(0, 128, 0));
		TitleLabel.setBounds(140, 57, 197, 16);
		Mainpanel.add(TitleLabel);
		setLocationRelativeTo(null);
	}
}
