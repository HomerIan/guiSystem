package guiSystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;

public class Algorithm extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Algorithm frame = new Algorithm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
	}

	public Algorithm() {

		String userName = "root";
		String password = "";
		String url = "jdbc:mysql://localhost:3306/guisystem?useSSL=false";

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 470, 373);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		setLocationRelativeTo(null);

		JButton btnNewButton = new JButton("SELECTION SORTING");
		btnNewButton.setBackground(SystemColor.controlHighlight);
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Tahoma", Font.ITALIC, 13));
		btnNewButton.setBounds(137, 89, 165, 35);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("STRING MATCHING");
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(SystemColor.controlHighlight);
		btnNewButton_1.setFont(new Font("Tahoma", Font.ITALIC, 13));
		btnNewButton_1.setBounds(137, 139, 165, 35);
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("KNAPSACK");
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBackground(SystemColor.controlHighlight);
		btnNewButton_2.setFont(new Font("Tahoma", Font.ITALIC, 13));
		btnNewButton_2.addActionListener(new ActionListener()

		{

			public void actionPerformed(ActionEvent e)

			{
				String capacity;
				capacity = JOptionPane.showInputDialog("Enter Knapsack Capacity");
				int cap = Integer.parseInt(capacity);

				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection(url, userName, password);
					String sqlKnapsack = "SELECT s.custNo,sd.transNo, SUM(p.price*sd.quantity) AS 'Total Amount', SUM(p.weight*sd.quantity) AS 'Total weight' FROM sales s RIGHT JOIN salesdetail sd ON s.transNo = sd.transNo RIGHT JOIN product p ON sd.prodcode = p.prodcode GROUP BY s.custNo,sd.transNo";
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(sqlKnapsack);
					ArrayList<String> custList = new ArrayList<String>();
					ArrayList<Integer> weightList = new ArrayList<Integer>();
					ArrayList<Integer> valueList = new ArrayList<Integer>();
					while (rs.next()) {
						custList.add(rs.getString("custNo"));
						weightList.add(rs.getInt("Total weight"));
						valueList.add(rs.getInt("Total Amount"));
					}
					// CONVERT ARRAYLIST TO ARRAY
					String[] custlist = custList.toArray(new String[custList.size()]);
					Integer[] weightlist = weightList.toArray(new Integer[weightList.size()]);
					Integer[] valuelist = valueList.toArray(new Integer[valueList.size()]);
					Knapsack.Knapsack(custlist, weightlist, valuelist, cap);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

			}
		});
		btnNewButton_2.setBounds(137, 187, 165, 35);
		panel.add(btnNewButton_2);

		JSeparator separator = new JSeparator();
		separator.setForeground(Color.GRAY);
		separator.setBounds(0, 78, 442, 2);
		panel.add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.GRAY);
		separator_1.setBounds(0, 230, 442, 2);
		panel.add(separator_1);

		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.GRAY);
		separator_2.setBounds(33, 154, 368, 2);
		panel.add(separator_2);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pattern;
				pattern = JOptionPane.showInputDialog("ENTER PATTERN");
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection(url, userName, password);
					String sqlStringMatch = "SELECT custname FROM customer;";
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(sqlStringMatch);
					ArrayList<String> names = new ArrayList<String>();
					while (rs.next()) {
						names.add(rs.getString("custname"));// FETCHING DATA TO ARRAYLIST
					}
					String[] findname = names.toArray(new String[names.size()]);// CONVERT ARRAYLIST TO ARRAY
					int pos = StringMatching.StringMatching(findname, pattern);
					if (pos != -1) {
						JOptionPane.showMessageDialog(null, "FOUND");
					} else {
						JOptionPane.showMessageDialog(null, "NOT FOUND");
					}
					// closing database connection
					stmt.close();
					conn.close();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "\tCANCEL");

				}
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					java.sql.Connection conn = DriverManager.getConnection(url, userName, password);
					String sqlSelectionSort = "SELECT SUM(p.price*sd.quantity) AS 'Total Amount'"
							+ "	FROM salesdetail sd" + "	RIGHT JOIN product p" + "	ON sd.prodcode = p.prodcode"
							+ "	RIGHT JOIN customer_VIEW cv" + "	ON sd.transNo = cv.transNo"
							+ "	WHERE sd.transNo = cv.transNo" + "	GROUP BY sd.transNo;";

					PreparedStatement stmt = conn.prepareStatement(sqlSelectionSort);
					ResultSet rs = stmt.executeQuery(sqlSelectionSort);
					ArrayList<Integer> temptotalAmount = new ArrayList<Integer>();
					while (rs.next()) {
						temptotalAmount.add(rs.getInt("Total Amount"));// FETCHING DATA TO ARRAYLIST
					}
					Integer[] arr = new Integer[temptotalAmount.size()];// CONVERT ARRAYLIST TO ARRAY
					temptotalAmount.toArray(arr);
					SelectionSort.selectionSort(arr);// Selection Sort METHOD
					// closing database connection
					stmt.close();
					conn.close();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, ex);

				}

			}

		});
	}
}
