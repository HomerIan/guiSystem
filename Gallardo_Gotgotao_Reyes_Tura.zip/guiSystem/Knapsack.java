package guiSystem;

import java.util.Scanner;

public class Knapsack {

	static String remarks = null;

	public static void Knapsack(String custNum[], Integer weight[], Integer value[], int capacity) {
		int totalweight = 0, totalcost = 0;
		// SINGLE DIGIT
		for (int i = 0; i < custNum.length; i++) {
			totalweight = weight[i];
			totalcost = value[i];
			if (totalweight <= capacity) {
				remarks = "Accepted";
			} else {
				remarks = "Rejected";
			}
			System.out.println(custNum[i] + "\t" + totalweight + "\t" + totalcost + "\t" + remarks);
		}
		// 2 DIGITS COMBINATION
		int num1 = 0, num2 = 1, num3 = 1, num4 = 1;
		for (int i = 0; i < custNum.length * 2; i++) {
			totalweight = weight[num1] + weight[num1 + num2];
			totalcost = value[num1] + value[num1 + num2];
			if (totalweight <= capacity) {
				remarks = "Accepted";
			} else {
				remarks = "Rejected";
			}
			System.out.println(custNum[num1] + "," + custNum[num1 + num2] + "\t" + totalweight + "\t" + totalcost + "\t"
					+ remarks);
			++num2;
			if (num1 + num2 == 5)
				num1++;
			num2 = 1;
		}
		// 3 DIGITS COMBINATION
		num1 = 0;
		num2 = 1;
		num3 = 1;// REINITIALIZE
		for (int i = 0; i < custNum.length * 2; i++) {
			totalweight = weight[num1] + weight[num1 + num2] + weight[num1 + num2 + num3];
			totalcost = value[num1] + value[num1 + num2] + value[num1 + num2 + num3];
			if (totalweight <= capacity) {
				remarks = "Accepted";
			} else {
				remarks = "Rejected";
			}
			System.out.println(custNum[num1] + "," + custNum[num1 + num2] + "," + custNum[num1 + num2 + num3] + "\t"
					+ totalweight + "\t" + totalcost + "\t" + remarks);
			++num3;
			if (num1 + num2 + num3 == 5)
				num2++;
			num3 = 1;
			if (num1 + num2 == 4)
				num1++;
			num2 = 1;
		}
		// 4 DIGITS COMBINATION
		num1 = 0;
		num2 = 1;
		num3 = 1;// REINITIALIZE
		for (int i = 0; i < custNum.length; i++) {
			totalweight = weight[num1] + weight[num1 + num2] + weight[num1 + num2 + num3]
					+ weight[num1 + num2 + num3 + num4];
			totalcost = value[num1] + value[num1 + num2] + value[num1 + num2 + num3] + value[num1 + num2 + num3 + num4];
			if (totalweight <= capacity) {
				remarks = "Accepted";
			} else {
				remarks = "Rejected";
			}
			System.out.println(custNum[num1] + "," + custNum[num1 + num2] + "," + custNum[num1 + num2 + num3] + ","
					+ custNum[num1 + num2 + num3 + num4] + "\t" + totalweight + "\t" + totalcost + "\t" + remarks);
			++num4;
			if (num1 + num2 + num3 + num4 == 5)
				num3++;
			num4 = 1;
			if (num1 + num2 + num3 == 4)
				num2++;
			num3 = 1;
			if (num1 + num2 == 3)
				num1++;
			num2 = 1;

		}
		// 5 DIGITS COMBINATION
		for (int i = 0; i < 1; i++) {
			totalweight = weight[i] + weight[i + 1] + weight[i + 2] + weight[i + 3] + weight[i + 4];
			totalcost = value[i] + value[i + 1] + value[i + 2] + value[i + 3] + value[i + 4];
			if (totalweight <= capacity) {
				remarks = "Accepted";
			} else {
				remarks = "Rejected";
			}
			System.out.println(custNum[i] + "," + custNum[i + 1] + "," + custNum[i + 2] + "," + custNum[i + 3] + ","
					+ custNum[i + 4] + "\t" + totalweight + "\t" + totalcost + "\t" + remarks);
		}
	}
}
