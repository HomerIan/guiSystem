package guiSystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;
import java.awt.Color;
import javax.swing.JSeparator;
import java.awt.SystemColor;
import java.awt.Font;

public class CustomerReceipt extends JFrame {

	private JPanel contentPane;
	private JPanel Secondpanel;
	private JTextField searchCustNametextField;
	private JTable table;
	private JLabel custNameResultLabel;
	private JLabel totalAmountLabel;
	private JLabel salesDateLabel;
	private JSeparator separator_1;
	private JLabel lblTransaction;
	private JSeparator separator;
	private JSeparator separator_2;
	private JLabel lblDate;
	private JLabel TotalAmountLabel;
	private JButton Logoutbtn;
	private JButton ProceedButton;
	private JLabel searchCustNameLabel;
	private JLabel custNameLabel;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerReceipt frame = new CustomerReceipt();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public CustomerReceipt() {
		
		String userName = "root";
		String password = "";
		String url = "jdbc:mysql://localhost:3306/guisystem?useSSL=false";
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 572, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		Secondpanel = new JPanel();
		contentPane.add(Secondpanel, BorderLayout.CENTER);
		Secondpanel.setLayout(null);
		
		searchCustNameLabel = new JLabel("Search Name:");
		searchCustNameLabel.setBounds(26, 70, 89, 14);
		Secondpanel .add(searchCustNameLabel);
		
		searchCustNametextField = new JTextField();
		searchCustNametextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fullName = searchCustNametextField.getText();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection(url, userName, password);
					String sqlgetCustname ="SELECT * FROM customer WHERE custname = '"+searchCustNametextField.getText()+"'";

					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(sqlgetCustname);
					//TODO IF user input mismatch put JoptionPane and clear the table list
					while(rs.next()) {
						if(fullName.toUpperCase().equals(rs.getString("custname").toUpperCase())) {
							custNameResultLabel.setText(rs.getString("custname"));
							JOptionPane.showMessageDialog(null, "   FOUND SUCCESSFULLY");

							String sqlgetOrder = 
									"SELECT cv.transNo,p.description, p.price,sd.quantity, SUM(p.price*sd.quantity) AS 'amount'\r\n" + 
									"	FROM customer_VIEW cv\r\n" + 
									"	RIGHT JOIN salesdetail sd\r\n" + 
									"	ON cv.transNo = sd.transNo\r\n" + 
									"	RIGHT JOIN product p\r\n" + 
									"	ON sd.prodcode = p.prodcode\r\n" + 
									"	WHERE cv.custName = '"+rs.getString("custname")+"'\n" + 
									"	GROUP BY cv.transNo,p.description, p.price,sd.quantity;";
							
							PreparedStatement pst = conn.prepareStatement(sqlgetOrder);
							ResultSet rs1 = pst.executeQuery();
							table.setModel(DbUtils.resultSetToTableModel(rs1));
							
							String sqlgetTotalAmount = "SELECT sd.transNo,SUM(p.price*sd.quantity) AS 'Total Amount'\r\n" + 
									"	FROM salesdetail sd\r\n" + 
									"	RIGHT JOIN product p\r\n" + 
									"	ON sd.prodcode = p.prodcode\r\n" + 
									"	RIGHT JOIN customer_VIEW cv\r\n" + 
									"	ON sd.transNo = cv.transNo\r\n" + 
									"	WHERE cv.custName = '"+rs.getString("custname")+"'\n" + 
									"	GROUP BY sd.transNo;\r\n";
							
							Statement stmt1 = conn.createStatement();
							ResultSet rs2 = stmt1.executeQuery(sqlgetTotalAmount);
							
							while(rs2.next()) {
								totalAmountLabel.setText(rs2.getString("Total Amount"));
							}		
							String sqlgetsalesDate ="SELECT c.custNo, s.salesDate \r\n" + 
									"	FROM sales s" + 
									"	RIGHT JOIN customer c" + 
									"	ON s.custNo = c.custNo" + 
									"	WHERE custName = '"+fullName.toLowerCase()+"'";
							
							PreparedStatement pst1 = conn.prepareStatement(sqlgetsalesDate);
							ResultSet rs3 = pst1.executeQuery();
							while(rs3.next()) {
								salesDateLabel.setText(rs3.getString("salesDate"));
							}
							
						}else if(!fullName.toUpperCase().equals(rs.getString("custname").toUpperCase())){
							table.removeAll();
							JOptionPane.showMessageDialog(null, "NOT FOUND");
							
						}
					}
					stmt.close();
					conn.close();
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, ex);
				}
			}
		});
		searchCustNametextField.setBounds(111, 67, 143, 20);
		Secondpanel.add(searchCustNametextField);
		
		
		custNameLabel = new JLabel("Customer Name :");
		custNameLabel.setBounds(37, 148, 105, 14);
		Secondpanel.add(custNameLabel);
		//FILL customer NAME
		custNameResultLabel = new JLabel("N/A");
		custNameResultLabel.setBounds(149, 148, 105, 14);
		Secondpanel.add(custNameResultLabel);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 13));
		table.setBackground(new Color(230, 230, 250));
		table.setModel(new DefaultTableModel(new Object[][] {},new String[] {}));
		table.setBounds(62, 225, 414, 80);
		Secondpanel.add(table);
		
		ProceedButton = new JButton("PROCEED");
		ProceedButton.setForeground(Color.BLUE);
		ProceedButton.setFont(new Font("Candara Light", Font.BOLD, 14));
		ProceedButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Algorithm algo = new Algorithm();
				algo.setVisible(true);
				dispose();
			}
		});
		ProceedButton.setBounds(218, 364, 105, 23);
		Secondpanel.add(ProceedButton);
		
		
		Logoutbtn = new JButton("LOG-OUT");
		Logoutbtn.setFont(new Font("Candara Light", Font.BOLD, 15));
		Logoutbtn.setBackground(SystemColor.controlHighlight);
		Logoutbtn.setForeground(Color.RED);
		Logoutbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OnlineBookstore obk = new OnlineBookstore();
				obk.setVisible(true);
				dispose();
			}
		});
		
		Logoutbtn.setBounds(413, 23, 105, 23);
		Secondpanel.add(Logoutbtn);
		
		TotalAmountLabel = new JLabel("Total Amount :");
		TotalAmountLabel.setBounds(309, 306, 98, 14);
		Secondpanel.add(TotalAmountLabel);
		
		totalAmountLabel = new JLabel("N/A");
		totalAmountLabel .setBounds(395, 306, 64, 14);
		Secondpanel.add(totalAmountLabel );
		
		lblDate = new JLabel("Date:");
		lblDate.setBounds(378, 147, 56, 16);
		Secondpanel.add(lblDate);
		
		salesDateLabel = new JLabel("N/A");
		salesDateLabel.setBounds(413, 147, 72, 16);
		Secondpanel.add(salesDateLabel);
		
		separator_1 = new JSeparator();
		separator_1.setBounds(0, 100, 566, 2);
		Secondpanel.add(separator_1);
		
		lblTransaction = new JLabel("|TRANSCTION| DESCRPTION |     PRICE      |   QUALITY    |   AMOUNT    |");
		lblTransaction.setForeground(new Color(0, 102, 102));
		lblTransaction.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTransaction.setBounds(62, 204, 423, 16);
		Secondpanel.add(lblTransaction);
		
		separator = new JSeparator();
		separator.setBounds(62, 204, 414, 2);
		Secondpanel.add(separator);
		
		separator_2 = new JSeparator();
		separator_2.setBounds(62, 219, 414, 2);
		Secondpanel.add(separator_2);

		setLocationRelativeTo(null);
	}
}
